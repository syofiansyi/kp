<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>SELAMAT ANDA LULUS</title>
	<style>
	body{
		background-color: #f1c40f;
		-webkit-animation: color 5s ease-in  0s infinite alternate running;
		-moz-animation: color 5s linear  0s infinite alternate running;
		animation: color 5s linear  0s infinite alternate running;
	}
	/* Animasi + Prefix untuk browser */
	@-webkit-keyframes color {
	    0% { background-color: #f1c40f; }
	    32% { background-color: #e74c3c; }
	    55% { background-color: #9b59b6; }
	    76% { background-color: #16a085; }
	    100% { background-color: #2ecc71; }
	}
	@-moz-keyframes color {
	     0% { background-color: #f1c40f; }
	    32% { background-color: #e74c3c; }
	    55% { background-color: #9b59b6; }
	    76% { background-color: #16a085; }
	    100% { background-color: #2ecc71; }
	}
	@keyframes color {
	  0% { background-color: #f1c40f; }
	    32% { background-color: #e74c3c; }
	    55% { background-color: #9b59b6; }
	    76% { background-color: #16a085; }
	    100% { background-color: #2ecc71; }
	}
	h1{
	
	   margin-right: 10%;
	        text-transform: uppercase;
	                font-family: 'halvetica', sans-serif;
	                color: #ecf0f1;
	                font-size: 30pt;
	                text-align: center;
	                line-height: 350px;
	               letter-spacing: 0.2em

	}
	p{
		text-align: center;
	}
	a{
		text-decoration: none;
		color: #333;
	}
	</style>
</head>
<body>
<div  class="content">
	
	<h1>SELAMAT ANDA LULUS</h1>
	

</div>
</body>
</html>