        <script src="<?php echo base_url('assets/vendor/chart.js/chart.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/carbon.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/demo.js'); ?>"></script>
        <script>
            $(document).ready( function () {
                $('#myTable').DataTable();
            } );
        </script>
    </body>
</html>
