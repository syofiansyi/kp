  <div class="modal-body">
                                <img style="image-orientation:from-image" src="<?php echo base_url('/gambar/'.$operator->matkul_metopen) ?>" width="100%" />
                            </div>