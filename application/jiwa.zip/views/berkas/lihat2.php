
      <div class="card">

        <div class="card-header bg-primary">
          <b> File Skripsi</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->fileskrip) ?>" />
    </div>
     <div class="card-header bg-primary">
          <b>Kartu Bimbingan</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->kbskrip) ?>" />
    </div>
  <div class="card-header bg-primary">
          <b>Surat Izin</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->sizin) ?>" />
    </div>
  <div class="card-header bg-primary">
          <b>UKT</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->ukt) ?>" />
    </div>
  
  <div class="card-header bg-primary">
          <b>Transkrip</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->transkrip) ?>" />
    </div>
  
  <div class="card-header bg-primary">
          <b>LHS</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->lhs) ?>" />
    </div>
  
  <div class="card-header bg-primary">
          <b>KRS</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->krs) ?>" />
    </div>
  
  <div class="card-header bg-primary">
          <b>Ijazah</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->ijazah) ?>" />
    </div>
  
  <div class="card-header bg-primary">
          <b>NIM</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->nim) ?>" />
    </div>
  
  <div class="card-header bg-primary">
          <b>Foto</b>
        </div>
        <div class="card-body">   
  <embed  width="100%"  height="800px" src="<?php echo base_url('/gambar/'.$operator->foto) ?>" />
    </div>
  
