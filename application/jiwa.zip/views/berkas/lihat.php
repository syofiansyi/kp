
<div class="container" id="bagas">
  
  <div class="row" >
    <div class="col-sm-8 col-sm-offset-8">
      <div class="card">
        <div class="card-header bg-primary">
          <b>Berkas Syarat Seminar</b>
        </div>
        <div class="card-body">   
     <div class="card-body">  
     <table>
  <tr>
    <td > <a class="btn btn-primary"href="<?php echo base_url('/gambar/'.$operator->fileskrip) ?>" ><b>File Skripsi</b> </a></td>
    <td > <a class="btn btn-primary"href="<?php echo base_url('/gambar/'.$operator->kbskrip) ?>" ><b>Kartu Bimbingan</b> </a></td>
    <td >  <a class="btn btn-primary"href="<?php echo base_url('/gambar/'.$operator->sizin) ?>" ><b>Surat Izin Seminar</b> </a></td>
    <td > <a class="btn btn-primary" href="<?php echo base_url('/gambar/'.$operator->ijazah) ?>" ><b>Ijazah</b> </a></td>
    <td > <a class="btn btn-primary" href="<?php echo base_url('/gambar/'.$operator->transkrip) ?>" ><b>Transkrip</b> </a></td>
  </tr>
  <tr>
    <td > <a class="btn btn-primary"
  href="<?php echo base_url('/gambar/'.$operator->lhs) ?>" ><b>LHS</b> </a></td>
  <td > <a class="btn btn-primary"
  href="<?php echo base_url('/gambar/'.$operator->krs) ?>" ><b>KRS</b> </a></td>
  <td ><a class="btn btn-primary"
  href="<?php echo base_url('/gambar/'.$operator->ukt) ?>" ><b>UKT</b> </a></td>
  <td ><a class="btn btn-primary"
  href="<?php echo base_url('/gambar/'.$operator->nim) ?>" ><b>NIM</b> </a></td>
  <td > <a class="btn btn-primary"
  href="<?php echo base_url('/gambar/'.$operator->foto) ?>" ><b>Foto</b> </a></td>
  </tr>
</table> 
</div>
</div>
</div>
</div>
</div>
</div>
<style type="text/css">#bagas{

  margin-left:15%; 
}
</style>  

