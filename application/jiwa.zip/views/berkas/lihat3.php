 

<div class="row" style="margin-left: 25%" >
    
      <div class="card">

        <div class="card-header bg-primary">
          <b>Data Kartu Bimbingan</b>
        </div>
        <div class="card-body">   
 <a href="<?php echo base_url('/gambar/'.$operator->kb_semprop) ?>" target="_blank">Lihat</a>
    </div>
  
